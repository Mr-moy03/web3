<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario_model extends CI_Model {

	// Función para obtener todos los usuarios
	public function obtener_usuarios()
	{
		// Esto es como hacer: "SELECT * FROM usuarios"
		$query = $this->db->get('usuarios');

		// Devuelve los resultados como un array
		return $query->result();
	}
}
